import React from "react";
import { useState } from "react";
import { useLocation } from "react-router";
import Layout from "./Layout";
function AddSlot() {
  const location = useLocation();
  const [slotsArray, setSlotsArray] = useState([]); //stores starttimes
  const [date, setDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const memberType = "User"; // replace with the actual member type
  const Email = location.state; // replace with the actual member email
  console.log("EMAIL: ", Email);

  const handleChange = (e) => {
    const value = e.target.value;
    const checked = e.target.checked;
    console.log(value, checked);
    if (checked) {
      setStartTime(value);
      setSlotsArray([...slotsArray, { startTime }]);
    } else {
      setSlotsArray(slotsArray.filter((e) => e !== value));
    }
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Slot Array : " + slotsArray);

    slotsArray.forEach((slot) => {
      const { startTime } = slot;
      //convert email to string
      const emailString = Email.id.toString();
      const email = emailString;
      console.log("Email String: ", emailString);
      const slotParams = { date, startTime, memberType, email };

      fetch("http://localhost:8080/api/v1/slots/editSlotEmail", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(slotParams),
      })
        .then(() => {
          console.log("Member added to slot:", slotParams);
        })
        .catch((error) => {
          console.error("Error adding member to slot:", error);
        });
    });
  };
  return (
    <Layout>
      <div>
        <form onSubmit={handleSubmit}>
          <label>&nbsp;Date : </label>
          <input type="date" onChange={(e) => setDate(e.target.value)} />
          &nbsp;
          <label>Select Slots : &nbsp;</label>
          &nbsp;
          <input
            type="checkbox"
            name="startTime"
            value="09:00:00"
            onChange={handleChange}
          />
          <label>&nbsp;9:00-10:00</label>
          &nbsp;
          <input
            type="checkbox"
            name="startTime"
            value="10:00:00"
            onChange={handleChange}
          />
          <label>&nbsp;10:00-11:00</label>
          &nbsp;
          <input
            type="checkbox"
            name="startTime"
            value="11:00:00"
            onChange={handleChange}
          />
          <label>&nbsp;11:00-12:00</label>
          &nbsp;
          <input
            type="checkbox"
            name="startTime"
            value="12:00:00"
            onChange={handleChange}
          />
          <label>&nbsp;12:00-1:00</label>
          &nbsp;
          <input
            type="checkbox"
            name="startTime"
            value="13:00:00"
            onChange={handleChange}
          />
          <label>&nbsp;1:00-2:00</label>
          &nbsp;
          <input
            type="checkbox"
            name="startTime"
            value="14:00:00"
            onChange={handleChange}
          />
          <label>&nbsp;2:00-3:00</label>
          &nbsp;
          <input
            type="checkbox"
            name="startTime"
            value="15:00:00"
            onChange={handleChange}
          />
          <label>&nbsp;3:00-4:00</label>
          &nbsp;
          <input
            type="checkbox"
            name="startTime"
            value="16:00:00"
            onChange={handleChange}
          />
          <label>&nbsp;4:00-5:00</label>
          &nbsp;
          <br />
          <br />
          <input type="submit" value="Add Slot" />
        </form>
      </div>
    </Layout>
  );
}

export default AddSlot;
