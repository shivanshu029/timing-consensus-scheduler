import React, { useState, useEffect } from "react";
import Layout from "./Layout";
//import { useLocation } from 'react-router';

function BookFacility() {
  const [date, setDate] = useState("");
  const [email, setFacilityEmail] = useState();
  const [availableSlots, setAvailableSlots] = useState([]);
  const [startTime, setStartTime] = useState();
  const [slotsArray, setSlotsArray] = useState([]);
  const memberType = "Facility";
  //const location = useLocation();

  useEffect(() => {
    if (email && date) {
      // Fetch available slots for the selected email and date
      fetch(
        `http://localhost:8080/api/v1/slots/getSlots?emails=${email}&date=${date}`
      )
        .then((response) => response.json())
        .then((data) => {
          // Extract the start times from the fetched data
          const startTimes = data.map((slot) => slot.startTime);
          setAvailableSlots(startTimes);
        });
    }
  }, [email, date]);

  console.log("availableSlots: ", availableSlots)

  const handleChange = (e) => {
    const value = e.target.value;       // selected slot start time
    console.log("selectedSlot: ", value, "Type: ", typeof selectedSlot);
    const isChecked = e.target.checked;
    if (isChecked) {
      // Check if the selected slot is available
      if (availableSlots.length > 0 && availableSlots.includes(value)) {
        setStartTime(value);
        setSlotsArray([...slotsArray, { startTime }]);
        console.log("slotsArray: ", slotsArray)
      } else {
        alert(`${value} is not available`);
      }
    } else {
        setSlotsArray(slotsArray.filter((slot) => slot.startTime !== value));
    }
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("email: ",email,"date: ", date);
    console.log("slotsArray: ", slotsArray);

    slotsArray.forEach((slot) => {
        const { startTime } = slot;
        
        const slotParams = { date, startTime, memberType, email };
  
        fetch("http://localhost:8080/api/v1/slots/editSlotEmail", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(slotParams),
        })
          .then(() => {
            console.log("Facility booked for:", slotParams);
          })
          .catch((error) => {
            console.error("Error adding facility to slot:", error);
          });
      });
  };

  return (
    <Layout>
    <div>
      <form onSubmit={handleSubmit}>
        <label> Emails : </label>
        <input
          type="text"
          onChange={(e) => setFacilityEmail(e.target.value)}
        />
        <label> Date : </label>
        <input type="date" onChange={(e) => setDate(e.target.value)} />
        <br />
        <br />
        <label>Select Slots : &nbsp;</label>
        &nbsp;
        <input
          type="checkbox"
          name="startTime"
          value="09:00:00"
          onChange={handleChange}
        />
        <label>&nbsp;9:00-10:00</label>
        &nbsp;
        <input
          type="checkbox"
          name="startTime"
          value="10:00:00"
          onChange={handleChange}
        />
        <label>&nbsp;10:00-11:00</label>
        &nbsp;
        <input
          type="checkbox"
          name="startTime"
          value="11:00:00"
          onChange={handleChange}
        />
        <label>&nbsp;11:00-12:00</label>
        &nbsp;
        <input
          type="checkbox"
          name="startTime"
          value="12:00:00"
          onChange={handleChange}
        />
        <label>&nbsp;12:00-1:00</label>
        &nbsp;
        <input
          type="checkbox"
          name="startTime"
          value="13:00:00"
          onChange={handleChange}
        />
        <label>&nbsp;1:00-2:00</label>
        &nbsp;
        <input
          type="checkbox"
          name="startTime"
          value="14:00:00"
          onChange={handleChange}
        />
        <label>&nbsp;2:00-3:00</label>
        &nbsp;
        <input
          type="checkbox"
          name="startTime"
          value="15:00:00"
          onChange={handleChange}
        />
        <label>&nbsp;3:00-4:00</label>
        &nbsp;
        <input
          type="checkbox"
          name="startTime"
          value="16:00:00"
          onChange={handleChange}
        />
        <label>&nbsp;4:00-5:00</label>
        &nbsp;
        <br />
        <br />
        <input type="submit" value="Book Facility" />
      </form>
    </div> </Layout>
  );
}

export default BookFacility;
