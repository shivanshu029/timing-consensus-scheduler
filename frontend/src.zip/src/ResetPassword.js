import React, { useState } from "react";
import { useLocation } from "react-router";
import Layout from "./Layout";

function ResetPassword() {
  const location = useLocation();
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [message, setMessage] = useState("");
  const Email = location.state;
  console.log("EMAIL: ", Email);

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    const emailString = Email.id.toString();
    const email = emailString;
    const slotParams = { email, oldPassword, newPassword };
  
    try{
    // Send a POST request to the server to change the password
    const response = await fetch("http://localhost:8080/api/v1/slots/resetPassword", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(slotParams),
    });
      const data = await response.json();
      if (response.ok) {
        alert("Password changed successfully.");
      } else {
        alert(data.message);
      }
    }catch(error) {
        alert("There was an error changing the password.");
    }
  };
  

  return (
    <Layout>
      <form onSubmit={handleSubmit}>
        <label>Old Password:</label>
        <input
          type="password"
          onChange={(e) => setOldPassword(e.target.value)}
        />

        <label>New Password:</label>
        <input
          type="password"
          onChange={(e) => setNewPassword(e.target.value)}
        />

        <br />
        <br />
        <input type="submit" value="Change Password" />
      </form>

      {message && <p>{message}</p>}
    </Layout>
  );
}

export default ResetPassword;
