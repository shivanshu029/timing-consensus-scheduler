import React from "react";
import { useHistory } from "react-router-dom";
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router';
import {useState} from 'react'
import Layout from "./Layout";

function Dashboard() {
  const navigate = useNavigate();
  const location=useLocation();
    console.log(location.state);
  function handleAddSlotClick() {
    navigate("/AddSlot",{state:location.state});
  }

  function handleCheckSlotClick() {
    navigate("/CheckSlot",{state:location.state});
  }

  function handleCheckSlotClick() {
    navigate("/BookFacility",{state:location.state});
  }

  return (
    <Layout>
    <div>
      <h1>Welcome to the Home Page</h1>
      <button onClick={handleAddSlotClick}>Add Slot</button>
      <button onClick={handleCheckSlotClick}>Check Slot</button>
      <button onClick={handleCheckSlotClick}>Book Facility</button>
    </div></Layout>
  );
}

export default Dashboard;
