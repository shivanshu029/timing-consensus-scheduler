import React, { useState, useEffect } from "react";
import Layout from "./Layout";
//import { useLocation } from 'react-router';

function CheckSlot() {
  const [date, setDate] = useState("");
  const [emails, setEmails] = useState([]);
  const [availableSlots, setAvailableSlots] = useState([]);
  //const location = useLocation();

  useEffect(() => {
    if (emails && date) {
      // Fetch available slots for the selected name and date
      fetch(
        `http://localhost:8080/api/v1/slots/getSlots?emails=${emails}&date=${date}`)
        .then((response) => response.json())
        .then((data) => setAvailableSlots(data));
    }
  }, [emails, date]);

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(emails, date);
    if (emails && date) {
      // Fetch available slots for the selected name and date
      console.log("memberIds", emails, "date", date);
      fetch(
        `http://localhost:8080/api/v1/slots/getSlots?emails=${emails}&date=${date}`
      ) //no cors
        .then((response) => response.json())
        .then((data) => setAvailableSlots(data));
      console.log("availableSlots", availableSlots);
    } else {
      setAvailableSlots([]);
    }
  };

  return (
    <Layout>
    <div>
      <form onSubmit={handleSubmit}>
        <label> Name : </label>
        <input type="text" onChange={(e) => setEmails(e.target.value)} />

        <label> Date : </label>
        <input type="date" onChange={(e) => setDate(e.target.value)} />

        <br />
        <br />
        <input type="submit" value="Check Slots" />
      </form>

      {availableSlots.length > 0 && (
        <div>
          <h2>Available Slots:</h2>
          <ul>
            {availableSlots.map((slot) => (
              <li key={slot.id}>{slot.startTime}</li>
            ))}
          </ul>
        </div>
      )}
    </div></Layout>
  );
}

export default CheckSlot;
